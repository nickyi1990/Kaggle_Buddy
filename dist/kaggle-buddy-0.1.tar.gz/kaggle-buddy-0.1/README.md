# Kaggle_Buddy
### requirements
numpy  
pandas  
Ipython  
pandas_summary  
sklearn  
tqdm  
keras  
matplotlib  
